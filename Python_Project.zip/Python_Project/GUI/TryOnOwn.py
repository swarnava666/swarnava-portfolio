numbers = [10,20,30,40]
a,b,c =numbers
print(a)
print(b)
print(c)