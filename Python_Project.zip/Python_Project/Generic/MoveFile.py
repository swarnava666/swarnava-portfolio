import os

source = "C:\\Users\\61097852\\Desktop\\ReadText.txt"
destination = "C:\\Users\\61097852\\Desktop\\ToCopy\\ReadText.txt"

try:
    if os.path.exists(destination):
        print("There is already a file")
    else:
        os.replace(source,destination)
        print(source+" was moved")
    
except FileNotFoundError:
    print(source +"was not found")
    