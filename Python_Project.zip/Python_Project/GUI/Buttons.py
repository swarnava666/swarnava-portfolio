from tkinter import *

window = Tk()
def click():
    print("You clicked the button")
    
button = Button(window,
                text="Click Me",
                command = click,
                font=("Comic Sans",30),
                fg="#00FF00",
                bg="black",
                activeforeground="#00FF00",
                activebackground="black",
                state=ACTIVE)
button.pack()

window.mainloop()