import { LightningElement,wire, api } from 'lwc';
import getRelatedFilesByRecordId from '@salesforce/apex/filePreviewAndDownloadController.getRelatedFilesByRecordId'
export default class PortfolioUserDetails extends LightningElement {
    @api recordId
    @api objectApiName
    @api resumeUrl

    downloadResume(){
        window.open(this.resumeUrl,"_blank")

        //window.open("https://github.com/swarnava666/swarnava-portfolio/raw/refs/heads/main/Swarnava_Chakraborty_Resume.docx","_blank")
        
    }
}