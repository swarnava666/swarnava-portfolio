squares = [i * i for i in range(1,11)]
newlist = [2,5,3,7,8]
squaresnew = [i * i for i in newlist]
print(squares)
print(squaresnew)


studentMarks = [100,90,80,70,60,50,40,30,20,10]
#passed_student = [i for i in studentMarks if i>=60]

passed_student = [i if i >=60 else "FALILED" for i in studentMarks]
print(passed_student)