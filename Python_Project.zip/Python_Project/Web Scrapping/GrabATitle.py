import requests
import bs4
result = requests.get("http://www.example.com")
#print(type(result))
soup = bs4.BeautifulSoup(result.text,"lxml")
#print(soup)
print(soup.select('title')[0].getText())