from tkinter import *

window =Tk() # instantiate an instance a window
window.geometry("420x420")
window.title("Bro code First GUI Program")
window.config(background="Black")
window.mainloop() #place window on screen

