student = ["ABC","MNO","TRU","DEF"]
student.sort()
print(student)


students = ("ABC","MNO","TRU","DEF")
sorted_students = sorted(students,reverse=True)
print(sorted_students)

newStudent =[("MNP","C",45),
             ("ABC","A",30),
             ("DEF","D",21)]

grade = lambda grades:grades[1]
newStudent.sort(key=grade)
print(newStudent)