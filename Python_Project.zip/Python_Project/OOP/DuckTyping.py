class Duck:
    def walk(self):
        print("Duck walking")
    def talk(self):
        print("Duck talking")
        
class Chicken:
    def walk(self):
        print("Chicken walking")
    def talk(self):
        print("Chicken talking")
        
class Person():
    def catch(self,duck):
        duck.walk()
        duck.talk()
        print("You caught the critter!")
        
duck = Duck()
chicken = Chicken()
person = Person()

person.catch(duck)