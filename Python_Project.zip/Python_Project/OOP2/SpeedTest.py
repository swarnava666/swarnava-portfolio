import speedtest

test = speedtest.SpeedTest()
download = test.download()
print(download)