def testFunc():
    print("Testing a function")


l=["Python"]
s=l[1]
print(s)