def create_cubes(n):
    
    for x in range(n):
        yield x**3 #generating values
    

#for x in create_cubes(10):
    #print(x)
    
    
def gen_fibbon(n):
    a=0
    b=1
    for i in range(n):
        yield a
        a,b = b,a+b
        
#for x in gen_fibbon(10):
  #  print(x)
  
def simple_gen():
    for x in range(3):
        yield x


for number in simple_gen():
    print(number)
    
g = simple_gen()
print(next(g))
print(next(g))
print(next(g))

s = 'hello'
s_iter = iter(s)
for letter in s:
    print(letter)
    
print(next(s_iter))