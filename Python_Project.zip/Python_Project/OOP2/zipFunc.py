username = ["Dude","Bro","Mr"]
password = ("p@ffsrd","test123","tuyr456")
login_date = ["1/1/2021","1/2/2021","1/3/2021"]

users = dict(zip(username,password))

users2 = zip(username,password,login_date)

print(type(users))
for key,value in users.items():
    print(key+":"+value)

for i in users2:
    print(i)