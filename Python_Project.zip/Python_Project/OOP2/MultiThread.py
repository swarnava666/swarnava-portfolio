#For IO bound process
import threading
import time


def eat_breakfast():
    time.sleep(5)
    print("Eat breakfst")
    
def drink_coffee():
    time.sleep(4)
    print("Drink coffee")
    
def study2():
    time.sleep(5)
    print("Finish Study")
    

x= threading.Thread(target=eat_breakfast,args =())
x.start()

y = threading.Thread(target=drink_coffee(),args =())
y.start()

z = threading.Thread(target=study2(),args =())
z.start()

x.join()
y.join()
z.join()
#eat_breakfast()
#drink_coffee()
#study2()

print(threading.active_count())
print(threading.enumerate())
print(time.perf_counter())