def double(x):
    return x*2

print(double(2))


double = lambda x:x*2
multiply = lambda x, y:x*y
age_check = lambda age:True if age>=18 else False
print(age_check(17))