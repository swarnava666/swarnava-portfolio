days = "Mon Tue Wed Thu Fri Sat Sun"
months = "Jan\nFeb\nMar\nApr\nMay"
print("Here are the days: ", days)
print("Here are the months: ", months)