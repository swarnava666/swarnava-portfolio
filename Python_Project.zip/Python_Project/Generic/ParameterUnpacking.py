from sys import argv
script, first, second, third = argv

print("The script: ", script)
print("Your first var: ", first)
print("Your sec var: ",second)
print("Your thrd var: ",third)