import os

path2 = "C:\\Users\\61097852\\Desktop\\NewFile.txt"

os.remove(path2)