import shutil

path = "C:\\Users\\61097852\\Desktop\\ReadText.txt"
path2 = "C:\\Users\\61097852\\Desktop\\NewFile.txt"
path3 = "C:\\Users\\61097852\\Desktop\\CopyFile.txt"

shutil.copyfile(path,path3) #source & dest
