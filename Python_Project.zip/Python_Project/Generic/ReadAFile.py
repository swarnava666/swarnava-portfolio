import os
path = "C:\\Users\\61097852\\Desktop\\ReadText.txt"
path2 = "C:\\Users\\61097852\\Desktop\\NewFile.txt"
#Read a file
if os.path.exists(path):
    print("Location exists!")
    if os.path.isfile(path):
        print("Is File!")
        try:
            with open('test.txt') as file:
                print(file.read())
        except FileNotFoundError:
            print("File not found")
    elif os.path.isdir(path):
        print("Is Folder")
else:
    print("Path doesn't exists!")

#writing a file
text = "Hi there this is swarnava writing a file \n"  
text2 = "Overwritten text"
with open(path2,'w') as file:
    file.write(text)
with open(path2,'a') as file:
    file.write(text2)
