import { LightningElement,wire,api } from 'lwc';
import PortfolioAssets from '@salesforce/resourceUrl/PortfolioAssets'
import {getRecord,getFieldValue} from 'lightning/uiRecordApi';
import FULLNAME from '@salesforce/schema/Portfolio__c.FullName__c'
import DESIGNATION from '@salesforce/schema/Portfolio__c.Designation__c'
import COMPANY_LOCATION from '@salesforce/schema/Portfolio__c.CompanyLocation__c'
import COMPANY_NAME from '@salesforce/schema/Portfolio__c.CompanyName__c'
export default class PortfolioBanner extends LightningElement {
    @api recordId //='a00gK000000tOmVQAU'
    @api trailheadUrl// = 'https://www.salesforce.com/trailblazer/schakraborty11'
    @api linkedinURL// = 'https://in.linkedin.com/in/swarnava-chakraborty-376b16101'

    userPic = `${PortfolioAssets}/PortfolioAssets/userPic.PNG`
    linkedin = `${PortfolioAssets}/PortfolioAssets/Social/linkedin.svg`
    trailhead = `${PortfolioAssets}/PortfolioAssets/Social/trailhead.svg`

    @wire(getRecord,{recordId: '$recordId', fields:[FULLNAME,DESIGNATION,COMPANY_LOCATION,COMPANY_NAME]})
    portfolioData
    
    get fullName(){
        return getFieldValue(this.portfolioData.data,FULLNAME)
    }
    get designation(){
        return getFieldValue(this.portfolioData.data,DESIGNATION)
    }
    get companyLocation(){  
        return getFieldValue(this.portfolioData.data,COMPANY_LOCATION)
    }
    get companyName(){
        return getFieldValue(this.portfolioData.data,COMPANY_NAME)
    }
    
}