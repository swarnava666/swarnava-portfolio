from car import Car

Car.wheels = 3
car_1 = Car("Chevy","Corvet",2021,"Blue")
car_2 = Car("Ford","msutang",2022,"Red")
car_1.wheels = 2
print(car_2.make)
print(car_2.model)
print(car_2.year)
print(car_2.color)
print(car_1.wheels)
print(car_2.wheels)

car_1.drive()
car_1.stop()

print(Car.wheels)