import { LightningElement } from 'lwc';

export default class BmiCalculator extends LightningElement {
    height = ''
    weight = ''
    bmiValue = ''
    result

    inputHandler(event){
        const {name, value} = event.target
        if(name === 'weight'){
            this.weight = value
        }else if(name === 'height'){
            this.height = value             //or this[name]=value
        }
    }


    submitHandler(event){
        event.preventDefault()
        console.log(this.height, this.weight)
        this.calculate()
    }

    calculate(){
        let height = Number(this.height)/100
        let weight = Number(this.weight)
        let bmi = weight / (height * height)
        this.bmiValue = Number(bmi.toFixed(2))
        if(this.bmiValue < 18.5){
            this.result = 'Underweight'
        }else if(this.bmiValue >=18.5 && this.bmiValue<25){
            this.result = 'Healthy'
        }else if(this.bmiValue >= 25 && this.bmiValue <29.9){
            this.result = 'Overweight'
        }else{
            this.result = 'Obese'
        }
        console.log("BMI value is: ", bmi)
        console.log("BMI value is: ", this.result)
        
    }

    recalculate(){
        this.result = ''
        this.height = ''
        this.weight = ''
        this.bmiValue = ''
    }

}