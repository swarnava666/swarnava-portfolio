newStudent =[("MNP","C",45),
             ("ABC","A",30),
             ("DEF","D",21)]

age_filter = lambda data:data[2]>21

new_age = list(filter(age_filter,newStudent))
new_age2 = list(filter(lambda data:data[2]>21,newStudent))
print(new_age)
print(new_age2)