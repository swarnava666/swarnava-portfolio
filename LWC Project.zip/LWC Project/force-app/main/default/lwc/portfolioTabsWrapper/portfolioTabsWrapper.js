import { LightningElement, api } from 'lwc';

export default class PortfolioTabsWrapper extends LightningElement {
    @api recordId //= 'a00gK000000tOmVQAU'
    @api objectApiName //= 'Portfolio__c'
}