from abc import ABC,abstractmethod
class Vehicle(ABC):
    @abstractmethod
    def go(self):
        pass
    
class Car(Vehicle):
    def go(self):
        print("Drive the car")
        
class Motorcycle(Vehicle):
    def go(self):
        print("Ride a motorcycle")
        
vehicle = Vehicle()
car = Car()
motocycle = Motorcycle()

vehicle.go()
car.go()
motocycle.go()