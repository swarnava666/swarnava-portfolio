import time

print(time.ctime(1000000000))

print(time.time())
print(time.ctime(time.time()))


time_obj = time.localtime()
print(time_obj)
format_time = time.strftime("%B %d %Y %H:%M:%S",time_obj)
print(format_time)

print(time.gmtime())

time_string = "20 April, 2020"
ttt = time.strptime(time_string,"%d %B, %Y")
print(ttt)

time_tuple = (2020, 4, 20, 4, 20, 0, 0, 0, 0)
time_string = time.asctime(time_tuple)
time_string2 = time.mktime(time_tuple)
print(time_string)
print(time_string2)