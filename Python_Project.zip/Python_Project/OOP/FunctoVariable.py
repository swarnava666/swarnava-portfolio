def hello():
    print("Hello")
    
print(hello)
hi = hello
print(hi)

say = print
say("WOW!!!")