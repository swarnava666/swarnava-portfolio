class Animal:
    def eat(self):
        print("Animal is eating")
        
class Rabbit(Animal):
    def eat(self):
        print("Rabbit is flying")
        
rabbit = Rabbit()
rabbit.eat()
