citiesInF = {'NY':32,'Boston':40,'LA':100,'Chicago':50}
weather = {'NY':'Snowing','Boston':'Sunny','LA':'Sunny','Chicago':'Snowy'}

citiesInC = {key:round((value - 32)*(5/9)) for (key,value) in citiesInF.items()}

sunny_weather = {key: value for (key,value) in weather.items() if value=="Sunny"}
citiesInChanged = {key: ("WARM" if value>=40 else "COLD")for (key,value) in citiesInF.items()}

def check_temp(value):
    if value >=40:
        return "HOT"
    elif 69>= value >=40:
        return "WARM"
    else:
        return "COLD"
    
    
citiesChanged2 = {key: check_temp(value) for (key,value) in citiesInF.items()}
print(citiesInC)
print(sunny_weather)
print(citiesInChanged)
print(citiesChanged2)