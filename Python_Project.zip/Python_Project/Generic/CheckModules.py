#import messages as msg
from messages import hello,bye

hello()
bye()

help("modules")