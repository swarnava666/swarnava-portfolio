foods = list()
while food :=input("What food do you like? ") != "quit":
    foods.append(food)