def hello():
    print("Hello! have a nice day!")
    
def bye():
    print("Have a wonderful time!")