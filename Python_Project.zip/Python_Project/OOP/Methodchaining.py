class Car:
    def turnon(self):
        print("On")
        return self
        
    def drive(self):
        print("Drive")
        return self
        
    def brake(self):
        print("Brake")
        return self
        
    def turnoff(self):
        print("Turn off")
        return self
        
car = Car()

car.turnon()\
    .drive()\
    .brake()\
    .turnoff()