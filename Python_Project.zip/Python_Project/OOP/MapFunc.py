newStudent =[("MNP","C",45),
             ("ABC","A",30),
             ("DEF","D",21)]

to_euros = lambda data:(data[0],data[2]*3)
append_name = lambda datam:(datam[0]+"CHANGED",datam[1],datam[2])
new_name = list(map(append_name,newStudent))
print(new_name)
store_euros = list(map(to_euros,newStudent))
print(store_euros)

#newList = [10,20,30]
#new_list = 
